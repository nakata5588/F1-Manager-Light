// src/pages/Standings.jsx
import React, { useMemo, useState } from "react";
import { useGame } from "../state/GameStore.js";

/* ===== Pequenos helpers ===== */
function firstArray(...cands) { for (const c of cands) if (Array.isArray(c)) return c; return []; }
function safeStr(v) { return v == null ? "" : String(v); }
function byAlpha(getKey) { return (a, b) => safeStr(getKey(a)).localeCompare(safeStr(getKey(b))); }

/** Normaliza standings vindos do save em vários formatos */
function normalizeStandings(raw) {
  if (!raw) return { drivers: [], teams: [] };
  const drivers = firstArray(raw.drivers);
  const constructors = firstArray(raw.constructors);
  const teams = constructors.length ? constructors : firstArray(raw.teams);
  return { drivers, teams };
}

/** Index rápido por id (string) */
function mapById(items, pickId) {
  const m = new Map();
  for (const it of items || []) {
    const id = pickId(it);
    if (id != null && id !== "") m.set(String(id), it);
  }
  return m;
}

export default function Standings() {
  const gameState = useGame((s) => s.gameState);
  const [tab, setTab] = useState("teams"); // "teams" | "drivers"

  if (!gameState) {
    return (
      <div className="bg-white rounded-xl shadow p-4">
        <h3 className="text-base font-semibold">No save loaded</h3>
        <p className="text-sm text-gray-600 mt-1">Load or start a new game to see standings.</p>
      </div>
    );
  }

  // DBs/base
  const season     = gameState.activeYear ?? gameState.season ?? null;
  const driversDb  = firstArray(gameState.drivers, gameState.dbDrivers);
  const teamsDb    = firstArray(gameState.teams, gameState.dbTeams);
  const contracts  = firstArray(gameState.contracts, gameState.dbContracts);
  const standings0 = normalizeStandings(gameState.standings);

  // Índices úteis
  const driversById   = useMemo(() => mapById(driversDb, (d) => d.driver_id ?? d.id ?? d.driverId), [driversDb]);
  const teamsById     = useMemo(() => mapById(teamsDb, (t) => t.team_id ?? t.id ?? t.teamId), [teamsDb]);
  const teamNameById  = (id) => teamsById.get(String(id))?.team_name || teamsById.get(String(id))?.name || "";

  /* ====== DRIVERS ====== */
  const driverStandings = useMemo(() => {
    // pontos/pos de standings (se existirem)
    const sMap = new Map();
    for (const r of standings0.drivers) {
      const id = String(r.driver_id ?? r.id ?? r.driverId ?? "");
      if (!id) continue;
      sMap.set(id, { points: Number(r.points ?? 0) || 0, position: r.position ?? null, team_id: r.team_id ?? r.constructor_id ?? r.teamId ?? null });
    }

    // construir lista com TODOS os pilotos da DB
    const rows = [];
    for (const d of driversDb) {
      const id = String(d.driver_id ?? d.id ?? d.driverId ?? "");
      if (!id) continue;
      const s = sMap.get(id) || { points: 0, position: null, team_id: null };

      // tenta descobrir a equipa atual do piloto via contracts, se standings não trouxer
      let team_id = s.team_id;
      if (team_id == null) {
        const teamContract = contracts.find((c) => {
          const pid = String(c.person_id ?? c.driver_id ?? c.id ?? "");
          const isDriverRole = String(c.role || "").toLowerCase().includes("driver") || pid.startsWith("d_");
          const sameYear = season == null || c.year == null || String(c.year) === String(season);
          return isDriverRole && pid === id && sameYear;
        });
        if (teamContract?.team_id != null) team_id = teamContract.team_id;
      }

      rows.push({
        driver_id: id,
        display_name: d.display_name || d.name || `${d.first_name ?? ""} ${d.last_name ?? ""}`.trim(),
        portrait_path: d.portrait_path || null,
        team_id: team_id ?? null,
        team_name: teamNameById(team_id) || d.team_name || "",
        points: s.points,
      });
    }

    // ordenar: por pontos desc; se todos 0, por nome asc
    const allZero = rows.every((r) => (r.points ?? 0) === 0);
    rows.sort(
      allZero
        ? byAlpha((r) => r.display_name)
        : (a, b) => (b.points ?? 0) - (a.points ?? 0) || safeStr(a.display_name).localeCompare(safeStr(b.display_name))
    );

    // recalcular posição 1..N
    rows.forEach((r, i) => (r.position = i + 1));
    return rows;
  }, [driversDb, contracts, season, standings0.drivers, teamsById]);

  /* ====== TEAMS ====== */
  const teamStandings = useMemo(() => {
    // pontos de standings (se existirem)
    const sTeams = standings0.teams;
    const sMap = new Map();
    for (const r of sTeams) {
      const id = String(r.team_id ?? r.id ?? r.teamId ?? r.constructor_id ?? "");
      if (!id) continue;
      sMap.set(id, Number(r.points ?? 0) || 0);
    }

    // construir lista com TODAS as equipas da DB (mesmo sem pontos)
    const rows = [];
    for (const t of teamsDb) {
      const id = String(t.team_id ?? t.id ?? t.teamId ?? "");
      if (!id) continue;
      const points = sMap.has(id) ? sMap.get(id) : 0;
      rows.push({
        team_id: id,
        team_name: t.team_name || t.name || "Team",
        logo_path: t.logo_path || t.brand_logo || null,
        points,
      });
    }

    // ordenar: por pontos desc; se todos 0, por nome asc
    const allZero = rows.every((r) => (r.points ?? 0) === 0);
    rows.sort(
      allZero
        ? byAlpha((r) => r.team_name)
        : (a, b) => (b.points ?? 0) - (a.points ?? 0) || safeStr(a.team_name).localeCompare(safeStr(b.team_name))
    );

    rows.forEach((r, i) => (r.position = i + 1));
    return rows;
  }, [teamsDb, standings0.teams]);

  return (
    <div className="grid gap-4">
      {/* Header + Tabs */}
      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Standings {season ? `• ${season}` : ""}</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setTab("teams")}
              className={`px-3 py-1.5 text-sm rounded ${tab === "teams" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"}`}
            >
              Constructors
            </button>
            <button
              onClick={() => setTab("drivers")}
              className={`px-3 py-1.5 text-sm rounded ${tab === "drivers" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700"}`}
            >
              Drivers
            </button>
          </div>
        </div>
      </div>

      {/* Tables */}
      {tab === "teams" ? (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="text-left">
                <th className="px-4 py-2 w-16">Pos</th>
                <th className="px-4 py-2">Team</th>
                <th className="px-4 py-2 w-24 text-right">Points</th>
              </tr>
            </thead>
            <tbody>
              {teamStandings.map((r) => (
                <tr key={r.team_id} className="border-t">
                  <td className="px-4 py-2">P{r.position}</td>
                  <td className="px-4 py-2">
                    <div className="flex items-center gap-3">
                      {r.logo_path ? (
                        <img
                          src={r.logo_path}
                          alt={r.team_name}
                          className="h-6 w-6 object-contain"
                          onError={(e) => (e.currentTarget.style.display = "none")}
                        />
                      ) : (
                        <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-gray-100 text-[10px] font-semibold">
                          {r.team_name.slice(0, 2).toUpperCase()}
                        </span>
                      )}
                      <button
                        type="button"
                        data-entity="team"
                        data-id={r.team_id}
                        className="text-blue-600 hover:underline cursor-pointer bg-transparent"
                      >
                        {r.team_name}
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-2 text-right font-semibold">{r.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!teamStandings.length && (
            <div className="px-4 py-6 text-sm text-gray-600">No teams found.</div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="text-left">
                <th className="px-4 py-2 w-16">Pos</th>
                <th className="px-4 py-2">Driver</th>
                <th className="px-4 py-2">Team</th>
                <th className="px-4 py-2 w-24 text-right">Points</th>
              </tr>
            </thead>
            <tbody>
              {driverStandings.map((r) => (
                <tr key={r.driver_id} className="border-t">
                  <td className="px-4 py-2">P{r.position}</td>
                  <td className="px-4 py-2">
                    <div className="flex items-center gap-3">
                      {r.portrait_path ? (
                        <img
                          src={r.portrait_path}
                          alt={r.display_name}
                          className="h-7 w-7 rounded object-cover"
                          onError={(e) => (e.currentTarget.style.display = "none")}
                        />
                      ) : (
                        <span className="inline-flex items-center justify-center h-7 w-7 rounded bg-gray-100 text-[10px] font-semibold">
                          {r.display_name.slice(0, 2).toUpperCase()}
                        </span>
                      )}
                      <button
                        type="button"
                        data-entity="driver"
                        data-id={r.driver_id}
                        className="text-blue-600 hover:underline cursor-pointer bg-transparent"
                      >
                        {r.display_name}
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-2">
                    {r.team_id ? (
                      <button
                        type="button"
                        data-entity="team"
                        data-id={r.team_id}
                        className="text-blue-600 hover:underline cursor-pointer bg-transparent"
                      >
                        {r.team_name || "—"}
                      </button>
                    ) : (
                      <span className="text-gray-600">—</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-right font-semibold">{r.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!driverStandings.length && (
            <div className="px-4 py-6 text-sm text-gray-600">No drivers found.</div>
          )}
        </div>
      )}
    </div>
  );
}
